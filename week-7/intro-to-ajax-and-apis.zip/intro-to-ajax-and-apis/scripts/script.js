// https://api.github.com/users/geraudmathe?client_id=33c836c79d14c686de01&client_secret=e0cfd41144d28831a6d10abf4e39c88085d1ee65

$(function(){

  function searchUserInfo(nickname){
    console.log("looking for info about" + nickname);
    $.ajax({
      url: "https://api.github.com/users/"+nickname+"?client_id=33c836c79d14c686de01&client_secret=e0cfd41144d28831a6d10abf4e39c88085d1ee65",
      success: function(data){
        console.log("result", data);
        $(".avatar").html("<img src='" + data["avatar_url"]+ "' />");
        $(".details h1").text(data["name"]);
        $("li .city").text(data["location"]);
        $("li .company").text(data["company"]);
        $("li .since").text(data["created_at"]);
      }
    })
  }

  $("#search").on("keypress", function(event){
    if(event.keyCode === 13){
      var nickname = $(this).val();
      searchUserInfo(nickname);
    }
    
  })
})