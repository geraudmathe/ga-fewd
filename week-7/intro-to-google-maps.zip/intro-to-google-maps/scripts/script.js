$(function(){
    var searchInput = $("#searchbox")

    var placesInput = new google.maps.places.SearchBox(searchInput[0])


    function myMap(){

      this.init = function(){
        var _this = this;
        var mapOptions = {
          zoom: 8,
          center: new google.maps.LatLng(51.515401, -0.071882),
          mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var canvas = $("#googleMap")[0];
        this.map = new google.maps.Map(canvas, mapOptions);
        $("#whereami").on("click", function(){
          _this.geoLocation()
        })
      }

      this.updateMapView = function(){

        var _this = this;
        google.maps.event.addListener(placesInput, 'places_changed', function(){
          var places = placesInput.getPlaces();

          var bounds = new google.maps.LatLngBounds();

          for(var i = 0;i < places.length; i++){
            var place = places[i];
            var marker = new google.maps.Marker({
              map: _this.map,
              title: place["name"],
              position: place.geometry.location
            });

            bounds.extend(place.geometry.location);
          }

          _this.map.fitBounds(bounds)
        })
      }

      this.geoLocation = function(){
        var _this = this;
        navigator.geolocation.getCurrentPosition(
          function(position){
            var coords = position.coords;
            var marker = new google.maps.Marker({
              map: _this.map,
              title: "you are here",
              position: new google.maps.LatLng(coords.latitude, coords.longitude)
            });
            _this.map.setZoom(17)
          }, // function called when location is updated
          function(){} // function called when location is unavilable
        );
      }

      this.init()
      this.updateMapView();

    }

    myMap();
})
